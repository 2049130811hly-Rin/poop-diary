const STORAGE_KEY = 'focusflow.tasks.v1';
const META_KEY = 'focusflow.meta.v1';

const taskForm = document.getElementById('taskForm');
const taskTitle = document.getElementById('taskTitle');
const taskDetail = document.getElementById('taskDetail');
const taskEnergy = document.getElementById('taskEnergy');
const taskDue = document.getElementById('taskDue');
const taskList = document.getElementById('taskList');
const emptyState = document.getElementById('empty');
const quickAdd = document.getElementById('quickAdd');
const pointsEl = document.getElementById('points');
const streakEl = document.getElementById('streak');
const todayDoneEl = document.getElementById('todayDone');
const rewardText = document.getElementById('rewardText');
const claimReward = document.getElementById('claimReward');
const filters = document.querySelectorAll('.chip');

let tasks = loadTasks();
let meta = loadMeta();
let activeFilter = 'all';

function loadTasks() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (error) {
    return [];
  }
}

function saveTasks() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
}

function loadMeta() {
  try {
    const raw = localStorage.getItem(META_KEY);
    return raw
      ? JSON.parse(raw)
      : { points: 0, streak: 0, today: todayKey(), doneToday: 0 };
  } catch (error) {
    return { points: 0, streak: 0, today: todayKey(), doneToday: 0 };
  }
}

function saveMeta() {
  localStorage.setItem(META_KEY, JSON.stringify(meta));
}

function todayKey() {
  const now = new Date();
  return now.toISOString().slice(0, 10);
}

function updateMetaDaily() {
  const today = todayKey();
  if (meta.today !== today) {
    if (meta.doneToday > 0) {
      meta.streak += 1;
    } else {
      meta.streak = 0;
    }
    meta.today = today;
    meta.doneToday = 0;
  }
}

function humanDue(date) {
  if (!date) return '未设置截止';
  return `截止：${date}`;
}

function energyLabel(level) {
  if (level === 'low') return '低能量';
  if (level === 'high') return '高能量';
  return '中等能量';
}

function makeId() {
  return `t_${Math.random().toString(36).slice(2, 9)}`;
}

function breakdownSteps(title, detail, energy) {
  const base = [
    '确认目标与完成标准',
    '列出需要的资料或工具',
    '安排一个 10 分钟专注时段',
    '完成最小可交付结果',
    '检查并收尾',
  ];

  const extra = [];
  const text = `${title} ${detail}`.toLowerCase();
  if (text.includes('分享') || text.includes('演示') || text.includes('报告')) {
    extra.push('整理核心结构与故事线');
    extra.push('制作 3-5 张关键页面');
    extra.push('预演 1 次并记录问题');
  }
  if (text.includes('整理') || text.includes('清理') || text.includes('收纳')) {
    extra.push('划分区域并设定范围');
    extra.push('先处理显眼的杂物');
    extra.push('标记需要后续处理的物品');
  }
  if (text.includes('学习') || text.includes('复习')) {
    extra.push('确定今日要完成的章节');
    extra.push('设置 25 分钟番茄钟');
    extra.push('写下 3 个关键要点');
  }

  let steps = [...base];
  if (energy === 'low') {
    steps = [
      '打开任务并写下 1 句话目标',
      '找出最容易开始的一步',
      '只做 5-10 分钟',
      '记录下一步',
    ];
  } else if (energy === 'high') {
    steps = [...base, ...extra];
  } else {
    steps = [...base.slice(0, 4), ...extra];
  }

  return steps.map((text, index) => ({
    id: `${index}_${Math.random().toString(36).slice(2, 6)}`,
    text,
    done: false,
  }));
}

function addTask({ title, detail, energy, due, steps }) {
  const task = {
    id: makeId(),
    title,
    detail,
    energy,
    due,
    createdAt: Date.now(),
    done: false,
    steps,
    note: '',
    penaltyApplied: false,
  };
  tasks.unshift(task);
  saveTasks();
  render();
}

function updatePoints(delta) {
  meta.points = Math.max(0, meta.points + delta);
  saveMeta();
  updateStats();
  updateReward();
}

function updateStats() {
  pointsEl.textContent = meta.points;
  streakEl.textContent = meta.streak;
  todayDoneEl.textContent = meta.doneToday;
}

function updateReward() {
  if (meta.points < 20) {
    rewardText.textContent = '完成 1 个任务后奖励自己 5 分钟休息。';
  } else if (meta.points < 60) {
    rewardText.textContent = '奖励自己 15 分钟喜欢的活动。';
  } else if (meta.points < 120) {
    rewardText.textContent = '安排一次 30 分钟的放松时间。';
  } else {
    rewardText.textContent = '计划一个小型奖励：咖啡、散步或喜欢的内容。';
  }
}

function applyPenaltyIfOverdue(task) {
  if (!task.due || task.done || task.penaltyApplied) return;
  const today = todayKey();
  if (task.due < today) {
    task.penaltyApplied = true;
    updatePoints(-10);
  }
}

function render() {
  taskList.innerHTML = '';
  updateMetaDaily();

  tasks.forEach((task) => {
    applyPenaltyIfOverdue(task);
  });
  saveTasks();
  updateStats();
  updateReward();

  const filtered = tasks.filter((task) => {
    if (activeFilter === 'done') return task.done;
    if (activeFilter === 'open') return !task.done;
    return true;
  });

  filtered.forEach((task) => {
    const node = document.getElementById('taskTemplate').content.cloneNode(true);
    const item = node.querySelector('.task');
    const toggle = node.querySelector('.task-toggle');
    const title = node.querySelector('.task-title');
    const metaEl = node.querySelector('.task-meta');
    const bar = node.querySelector('.bar');
    const subtasksEl = node.querySelector('.subtasks');
    const deleteBtn = node.querySelector('.delete');
    const addStepBtn = node.querySelector('.add-step');
    const reframeBtn = node.querySelector('.reframe');
    const editNoteBtn = node.querySelector('.edit-note');
    const noteEl = node.querySelector('.note');

    toggle.checked = task.done;
    title.textContent = task.title;
    metaEl.textContent = `${energyLabel(task.energy)} · ${humanDue(task.due)}`;
    noteEl.textContent = task.note || '写下备注或提醒…';
    noteEl.hidden = !task.note;

    const total = task.steps.length;
    const doneCount = task.steps.filter((step) => step.done).length;
    const percent = total === 0 ? 0 : Math.round((doneCount / total) * 100);
    bar.style.width = `${percent}%`;

    if (task.done) {
      item.classList.add('done');
    }

    task.steps.forEach((step) => {
      const sub = document.getElementById('subtaskTemplate').content.cloneNode(true);
      const subToggle = sub.querySelector('.subtask-toggle');
      const subText = sub.querySelector('.subtask-text');
      const removeBtn = sub.querySelector('.remove');
      subToggle.checked = step.done;
      subText.textContent = step.text;

      subToggle.addEventListener('change', () => {
        step.done = subToggle.checked;
        if (step.done) {
          updatePoints(5);
        }
        saveTasks();
        render();
      });

      subText.addEventListener('blur', () => {
        step.text = subText.textContent.trim() || '未命名子任务';
        saveTasks();
        render();
      });

      removeBtn.addEventListener('click', () => {
        task.steps = task.steps.filter((s) => s.id !== step.id);
        saveTasks();
        render();
      });

      subtasksEl.appendChild(sub);
    });

    toggle.addEventListener('change', () => {
      task.done = toggle.checked;
      if (task.done) {
        meta.doneToday += 1;
        updatePoints(20);
      }
      saveTasks();
      saveMeta();
      render();
    });

    title.addEventListener('blur', () => {
      task.title = title.textContent.trim() || '未命名任务';
      saveTasks();
      render();
    });

    deleteBtn.addEventListener('click', () => {
      tasks = tasks.filter((t) => t.id !== task.id);
      saveTasks();
      render();
    });

    addStepBtn.addEventListener('click', () => {
      task.steps.push({
        id: makeId(),
        text: '新的子任务',
        done: false,
      });
      saveTasks();
      render();
    });

    reframeBtn.addEventListener('click', () => {
      task.steps = breakdownSteps(task.title, task.detail || '', task.energy);
      task.done = false;
      saveTasks();
      render();
    });

    editNoteBtn.addEventListener('click', () => {
      noteEl.hidden = !noteEl.hidden;
      if (!noteEl.hidden && noteEl.textContent.trim() === '') {
        noteEl.textContent = '写下备注或提醒…';
      }
    });

    noteEl.addEventListener('blur', () => {
      const text = noteEl.textContent.trim();
      task.note = text === '写下备注或提醒…' ? '' : text;
      saveTasks();
    });

    taskList.appendChild(node);
  });

  emptyState.style.display = filtered.length === 0 ? 'block' : 'none';
}

function handleSubmit(event) {
  event.preventDefault();
  const title = taskTitle.value.trim();
  if (!title) return;
  const detail = taskDetail.value.trim();
  const energy = taskEnergy.value;
  const due = taskDue.value || '';
  const steps = breakdownSteps(title, detail, energy);
  addTask({ title, detail, energy, due, steps });
  taskForm.reset();
}

function handleQuickAdd() {
  const title = taskTitle.value.trim();
  if (!title) return;
  addTask({
    title,
    detail: taskDetail.value.trim(),
    energy: taskEnergy.value,
    due: taskDue.value || '',
    steps: [],
  });
  taskForm.reset();
}

filters.forEach((chip) => {
  chip.addEventListener('click', () => {
    filters.forEach((c) => c.classList.remove('active'));
    chip.classList.add('active');
    activeFilter = chip.dataset.filter;
    render();
  });
});

claimReward.addEventListener('click', () => {
  if (meta.points >= 20) {
    updatePoints(-20);
  } else {
    rewardText.textContent = '需要至少 20 积分才可兑换奖励。';
  }
});

taskForm.addEventListener('submit', handleSubmit);
quickAdd.addEventListener('click', handleQuickAdd);

render();
