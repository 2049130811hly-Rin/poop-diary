const STORAGE_KEY = 'poop_records';
const SETTINGS_KEY = 'poop_settings_v1';
const DEFAULT_CENTER = [31.2304, 121.4737];
const RANGE_LABELS = {
  week: '最近 7 天',
  month: '最近 30 天',
  halfyear: '最近半年',
  year: '最近一年',
};
const ANALYSIS_LABELS = {
  shape: '形状分布',
  location: '地点分布',
  mood: '心情分布',
  duration: '时长分布',
};
const THEME_OPTIONS = ['蓝色', '绿色', '蜜桃'];
const HOME_STYLE_OPTIONS = ['卡片', '极简'];
const NAV_STYLE_OPTIONS = ['胶囊', '扁平'];
const ICON_STYLE_OPTIONS = ['Emoji', '线性'];
const CHART_COLORS = ['#4f8ff3', '#b8dcb4', '#ffd59f', '#d6b5ef', '#ffbcbc', '#95d2ce'];
const APPROXIMATE_COORDS = {
  home: [31.2292, 121.4748],
  office: [31.2316, 121.4766],
  public: [31.2283, 121.4713],
};

const SHAPE_LABELS = {
  banana: '🍌 香蕉型',
  brick: '🧱 硬块型',
  liquid: '🌊 流体型',
};

const LOCATION_LABELS = {
  home: '🏠 家',
  office: '🏢 公司',
  public: '🚻 公共厕所',
};

const MOOD_LABELS = {
  relaxed: '😌 爽',
  neutral: '😐 平静',
  painful: '😫 痛苦',
};

const DURATION_LABELS = {
  3: '3 分钟',
  5: '5 分钟',
  8: '8 分钟',
  12: '12 分钟',
};

const contentLabels = {
  overview: '总览',
  shape: '形状',
  location: '地点',
  mood: '心情',
  duration: '时长',
};

const openModalBtn = document.getElementById('openModalBtn');
const closeModalBtn = document.getElementById('closeModalBtn');
const overlay = document.getElementById('overlay');
const recordModal = document.getElementById('recordModal');
const recentCard = document.getElementById('recentCard');
const recentTemplate = document.getElementById('recentTemplate');
const formError = document.getElementById('formError');
const prevStepBtn = document.getElementById('prevStepBtn');
const nextStepBtn = document.getElementById('nextStepBtn');
const saveRecordBtn = document.getElementById('saveRecordBtn');
const choiceButtons = Array.from(document.querySelectorAll('.choice'));
const stepIndicators = Array.from(document.querySelectorAll('[data-step-indicator]'));
const stepPanels = Array.from(document.querySelectorAll('[data-step-panel]'));
const views = Array.from(document.querySelectorAll('.view'));
const navItems = Array.from(document.querySelectorAll('.nav-item[data-route]'));
const mapNavItem = document.getElementById('mapNavItem');
const monthLabel = document.getElementById('monthLabel');
const prevMonthBtn = document.getElementById('prevMonthBtn');
const nextMonthBtn = document.getElementById('nextMonthBtn');
const calendarGrid = document.getElementById('calendarGrid');
const selectedDateTitle = document.getElementById('selectedDateTitle');
const selectedDateList = document.getElementById('selectedDateList');
const dayRecordTemplate = document.getElementById('dayRecordTemplate');
const totalCount = document.getElementById('totalCount');
const dailyAverage = document.getElementById('dailyAverage');
const averageDuration = document.getElementById('averageDuration');
const personaName = document.getElementById('personaName');
const personaDesc = document.getElementById('personaDesc');
const insightStats = document.getElementById('insightStats');
const insightEmpty = document.getElementById('insightEmpty');
const clearDataBtn = document.getElementById('clearDataBtn');
const personaDriver = document.getElementById('personaDriver');
const personaTip = document.getElementById('personaTip');
const confirmModal = document.getElementById('confirmModal');
const closeConfirmBtn = document.getElementById('closeConfirmBtn');
const cancelClearBtn = document.getElementById('cancelClearBtn');
const confirmClearBtn = document.getElementById('confirmClearBtn');
const homeTotalCount = document.getElementById('homeTotalCount');
const homeTodayCount = document.getElementById('homeTodayCount');
const homeAvgDuration = document.getElementById('homeAvgDuration');
const todayBadge = document.getElementById('todayBadge');
const contentSelectorButtons = Array.from(document.querySelectorAll('[data-content]'));
const timeFilterButtons = Array.from(document.querySelectorAll('[data-range]'));
const analysisButtons = Array.from(document.querySelectorAll('[data-analysis]'));
const analysisTabButtons = Array.from(document.querySelectorAll('[data-analysis-tab]'));
const analysisTitle = document.getElementById('analysisTitle');
const chartRing = document.getElementById('chartRing');
const chartPrimary = document.getElementById('chartPrimary');
const chartSecondary = document.getElementById('chartSecondary');
const chartLegend = document.getElementById('chartLegend');
const captureLocationInput = document.getElementById('captureLocationInput');
const mapCanvas = document.getElementById('mapCanvas');
const mapDetailTitle = document.getElementById('mapDetailTitle');
const mapDetailList = document.getElementById('mapDetailList');
const locateLatestBtn = document.getElementById('locateLatestBtn');
const toggleMap3dBtn = document.getElementById('toggleMap3dBtn');
const themeColorValue = document.getElementById('themeColorValue');
const homeStyleValue = document.getElementById('homeStyleValue');
const navStyleValue = document.getElementById('navStyleValue');
const iconStyleValue = document.getElementById('iconStyleValue');
const toggleMapBtn = document.getElementById('toggleMapBtn');
const toggleHomeCardBtn = document.getElementById('toggleHomeCardBtn');
const showMapToggle = document.getElementById('showMapToggle');
const showHomeCardToggle = document.getElementById('showHomeCardToggle');
const optionButtons = Array.from(document.querySelectorAll('.option-item'));
const bottomNav = document.getElementById('bottomNav');
const homeHero = document.getElementById('homeHero');
const homeRecordCard = document.getElementById('homeRecordCard');

let currentStep = 1;
let formState = freshFormState();
let records = loadRecords();
let settings = loadSettings();
let currentRoute = 'home';
let calendarCursor = currentMonthCursor();
let selectedDate = '';
let insightRange = 'week';
let insightContent = 'overview';
let analysisDimension = 'shape';
let mapInstance = null;
let mapMarkers = [];
let mapSatelliteLike = false;

function freshFormState() {
  return {
    shape: '',
    location: '',
    mood: '',
    duration: '',
  };
}

function defaultSettings() {
  return {
    themeColor: '蓝色',
    homeStyle: '卡片',
    navStyle: '胶囊',
    iconStyle: 'Emoji',
    showMap: true,
    showHomeCard: true,
  };
}

function makeId() {
  return `poop_${Math.random().toString(36).slice(2, 10)}`;
}

function todayDate() {
  return new Date().toISOString().slice(0, 10);
}

function currentTime() {
  const now = new Date();
  const hour = String(now.getHours()).padStart(2, '0');
  const minute = String(now.getMinutes()).padStart(2, '0');
  return `${hour}:${minute}`;
}

function currentMonthCursor() {
  const now = new Date();
  return {
    year: now.getFullYear(),
    month: now.getMonth(),
  };
}

function formatTodayBadge() {
  const now = new Date();
  return `${now.getMonth() + 1} 月 ${now.getDate()} 日`;
}

function pad(num) {
  return String(num).padStart(2, '0');
}

function dateKey(year, month, day) {
  return `${year}-${pad(month + 1)}-${pad(day)}`;
}

function monthTitle(year, month) {
  return `${year} 年 ${month + 1} 月`;
}

function formatMinutes(value) {
  return `${Math.round(value || 0)}m`;
}

function buildEmptyState(title, copy, icon = '🫧', kicker = 'Nothing here yet') {
  return `
    <div class="empty-state">
      <div class="empty-emoji" aria-hidden="true">${icon}</div>
      <div class="empty-kicker">${kicker}</div>
      <div class="empty-title">${title}</div>
      <div class="empty-copy">${copy}</div>
    </div>
  `;
}

function loadSettings() {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return defaultSettings();
    return { ...defaultSettings(), ...JSON.parse(raw) };
  } catch (error) {
    localStorage.removeItem(SETTINGS_KEY);
    return defaultSettings();
  }
}

function saveSettings() {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

function migrateRecord(item) {
  const duration = Number(item.duration || item.durationMinutes || 0) || 5;
  const coordinates = item.coordinates && Array.isArray(item.coordinates)
    ? item.coordinates.map(Number)
    : null;

  return {
    id: typeof item.id === 'string' ? item.id : makeId(),
    date: typeof item.date === 'string' ? item.date : todayDate(),
    time: typeof item.time === 'string' ? item.time : currentTime(),
    shape: typeof item.shape === 'string' ? item.shape : '',
    location: typeof item.location === 'string' ? item.location : '',
    mood: typeof item.mood === 'string' ? item.mood : '',
    duration,
    coordinates,
    approx: Boolean(item.approx),
  };
}

function loadRecords() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item) => item && typeof item === 'object').map(migrateRecord).sort(sortByDateTimeDesc);
  } catch (error) {
    localStorage.removeItem(STORAGE_KEY);
    return [];
  }
}

function saveRecords() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
}

function clearAllRecords() {
  localStorage.removeItem(STORAGE_KEY);
  records = [];
  selectedDate = '';
  calendarCursor = currentMonthCursor();
  renderAll();
}

function sortByDateTimeDesc(a, b) {
  return `${b.date}T${b.time}`.localeCompare(`${a.date}T${a.time}`);
}

function countBy(items, key) {
  return items.reduce((map, item) => {
    const value = item[key];
    if (!value) return map;
    map[value] = (map[value] || 0) + 1;
    return map;
  }, {});
}

function mostCommon(items, key) {
  const entries = Object.entries(countBy(items, key));
  if (entries.length === 0) return null;
  entries.sort((a, b) => b[1] - a[1]);
  return entries[0][0];
}

function resolvePersona(items) {
  if (items.length === 0) {
    return {
      name: '还没有人格',
      desc: '先记录几次，我们再认真整活。',
      driver: '暂无主线索',
      tip: '先从首页记第一条开始。',
    };
  }

  const shape = mostCommon(items, 'shape');
  const location = mostCommon(items, 'location');
  const mood = mostCommon(items, 'mood');
  const durationAvg = average(items.map((item) => item.duration));

  if (shape === 'banana') {
    return {
      name: '🍌 香蕉型选手',
      desc: '你的排便模式整体稳定，节奏比较清楚，数据看起来也更容易形成规律。',
      driver: '香蕉型出现最多',
      tip: '继续保持喝水和作息，稳定就是你的王牌。',
    };
  }

  if (location === 'home') {
    return {
      name: '🏠 居家型选手',
      desc: '熟悉环境会明显提高你的舒适感，身体更愿意在安全区里放松输出。',
      driver: '在家记录次数最多',
      tip: '如果外出容易卡住，尽量给自己更稳定的节奏。',
    };
  }

  if (mood === 'relaxed') {
    return {
      name: '😌 放松型选手',
      desc: '你不是靠硬扛，而是靠放松进入状态。心情一顺，身体也会更配合。',
      driver: '“爽/放松”状态最多',
      tip: '越别催自己，越容易顺利完成。',
    };
  }

  if (durationAvg >= 8) {
    return {
      name: '⌛ 慢热型选手',
      desc: '你需要一点进入状态的时间，但一旦进入节奏，记录会越来越稳定。',
      driver: '平均时长偏长',
      tip: '给自己一个不被打扰的时间窗，会比催促更有效。',
    };
  }

  return {
    name: '💩 随机应变型选手',
    desc: '你的模式还在形成中，目前变化比较多。多记几次，规律就会慢慢出现。',
    driver: '目前还没有绝对主导模式',
    tip: '继续记录，样本一多，规律就会更清楚。',
  };
}

function average(values) {
  if (values.length === 0) return 0;
  return values.reduce((sum, value) => sum + Number(value || 0), 0) / values.length;
}

function startOfDay(date) {
  const copy = new Date(date);
  copy.setHours(0, 0, 0, 0);
  return copy;
}

function getFilteredRecords(range) {
  const now = startOfDay(new Date());
  const dayMap = { week: 7, month: 30, halfyear: 183, year: 365 };
  const days = dayMap[range] || 7;
  const threshold = new Date(now);
  threshold.setDate(now.getDate() - (days - 1));

  return records.filter((record) => {
    const recordDate = startOfDay(new Date(`${record.date}T00:00:00`));
    return recordDate >= threshold && recordDate <= now;
  });
}

function recordsForDate(date) {
  return records.filter((record) => record.date === date).sort(sortByDateTimeDesc);
}

function durationBucket(minutes) {
  const value = Number(minutes || 0);
  if (value <= 3) return '闪电 3 分';
  if (value <= 5) return '顺畅 5 分';
  if (value <= 8) return '常规 8 分';
  return '慢热 12 分';
}

function labelForDimension(dimension, value) {
  if (dimension === 'shape') return SHAPE_LABELS[value] || value;
  if (dimension === 'location') return LOCATION_LABELS[value] || value;
  if (dimension === 'mood') return MOOD_LABELS[value] || value;
  if (dimension === 'duration') return value;
  return value;
}

function normalizeDimensionRecords(items, dimension) {
  if (dimension === 'duration') {
    return items.map((item) => ({ ...item, durationBucket: durationBucket(item.duration) }));
  }
  return items;
}

function breakdownForDimension(items, dimension) {
  const normalized = normalizeDimensionRecords(items, dimension);
  const key = dimension === 'duration' ? 'durationBucket' : dimension;
  const counts = countBy(normalized, key);
  const total = Object.values(counts).reduce((sum, value) => sum + value, 0);
  return Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .map(([value, count], index) => ({
      value,
      label: labelForDimension(dimension, value),
      count,
      percent: total === 0 ? 0 : Math.round((count / total) * 100),
      color: CHART_COLORS[index % CHART_COLORS.length],
    }));
}

function approximateCoordinates(location) {
  return APPROXIMATE_COORDS[location] || DEFAULT_CENTER;
}

function getCurrentCoordinates() {
  return new Promise((resolve) => {
    if (!captureLocationInput.checked || !navigator.geolocation) {
      resolve(null);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve([position.coords.latitude, position.coords.longitude]);
      },
      () => {
        resolve(null);
      },
      { enableHighAccuracy: false, timeout: 3500, maximumAge: 300000 }
    );
  });
}

function openModal() {
  overlay.hidden = false;
  recordModal.hidden = false;
  currentStep = 1;
  formState = freshFormState();
  captureLocationInput.checked = true;
  syncChoices();
  syncStepper();
  syncButtons();
  hideError();
}

function closeModal() {
  overlay.hidden = true;
  recordModal.hidden = true;
  hideError();
}

function openConfirmModal() {
  overlay.hidden = false;
  confirmModal.hidden = false;
}

function closeConfirmModal() {
  overlay.hidden = true;
  confirmModal.hidden = true;
}

function showError(message) {
  formError.textContent = message;
  formError.hidden = false;
}

function hideError() {
  formError.hidden = true;
}

function syncChoices() {
  choiceButtons.forEach((button) => {
    const group = button.dataset.group;
    const value = button.dataset.value;
    button.classList.toggle('active', String(formState[group]) === value);
  });
}

function syncStepper() {
  stepIndicators.forEach((node) => {
    node.classList.toggle('active', Number(node.dataset.stepIndicator) === currentStep);
  });
  stepPanels.forEach((panel) => {
    panel.classList.toggle('is-active', Number(panel.dataset.stepPanel) === currentStep);
  });
}

function syncButtons() {
  prevStepBtn.hidden = currentStep === 1;
  nextStepBtn.hidden = currentStep === 4;
  saveRecordBtn.hidden = currentStep !== 4;
}

function validateStep(step) {
  if (step === 1 && !formState.shape) return false;
  if (step === 2 && !formState.location) return false;
  if (step === 3 && !formState.mood) return false;
  if (step === 4 && !formState.duration) return false;
  return true;
}

function goNext() {
  if (!validateStep(currentStep)) {
    showError('这一项还没选，先点一个选项再继续。');
    return;
  }
  hideError();
  currentStep = Math.min(4, currentStep + 1);
  syncStepper();
  syncButtons();
}

function goPrev() {
  hideError();
  currentStep = Math.max(1, currentStep - 1);
  syncStepper();
  syncButtons();
}

async function saveRecord() {
  if (!formState.shape || !formState.location || !formState.mood || !formState.duration) {
    showError('请选择所有选项。');
    return;
  }

  saveRecordBtn.disabled = true;
  const coordinates = await getCurrentCoordinates();
  const record = {
    id: makeId(),
    date: todayDate(),
    time: currentTime(),
    shape: formState.shape,
    location: formState.location,
    mood: formState.mood,
    duration: Number(formState.duration),
    coordinates: coordinates || approximateCoordinates(formState.location),
    approx: !coordinates,
  };

  records.unshift(record);
  records.sort(sortByDateTimeDesc);
  saveRecords();
  saveRecordBtn.disabled = false;
  closeModal();
  renderAll();
}

function renderRecentRecord() {
  recentCard.innerHTML = '';

  if (records.length === 0) {
    recentCard.classList.add('empty');
    recentCard.innerHTML = buildEmptyState(
      '暂无记录',
      '今天的“成果”准备好了吗？点下面按钮，4 步就能记下来。',
      '🫧',
      'No logs yet'
    );
    return;
  }

  recentCard.classList.remove('empty');
  const latest = records[0];
  const fragment = recentTemplate.content.cloneNode(true);

  fragment.getElementById('recentTime').textContent = latest.time;
  fragment.getElementById('recentShape').textContent = formatLabel('shape', latest.shape);
  fragment.getElementById('recentLocation').textContent = formatLabel('location', latest.location);
  fragment.getElementById('recentMood').textContent = formatLabel('mood', latest.mood);
  fragment.getElementById('recentDuration').textContent = formatLabel('duration', latest.duration);
  fragment.getElementById('recentDate').textContent = `${latest.date} 记录 ${latest.approx ? '· 近似位置' : '· 含定位'}`;

  recentCard.appendChild(fragment);
}

function formatLabel(type, value) {
  if (type === 'shape') return SHAPE_LABELS[value] || value;
  if (type === 'location') return LOCATION_LABELS[value] || value;
  if (type === 'mood') return MOOD_LABELS[value] || value;
  if (type === 'duration') return DURATION_LABELS[value] || `${value} 分钟`;
  return value;
}

function renderHomeStats() {
  const total = records.length;
  const todayTotal = records.filter((record) => record.date === todayDate()).length;
  homeTotalCount.textContent = String(total);
  homeTodayCount.textContent = String(todayTotal);
  homeAvgDuration.textContent = formatMinutes(average(records.map((item) => item.duration)));
  todayBadge.textContent = formatTodayBadge();
}

function setRoute(route) {
  if (route === 'map' && !settings.showMap) {
    route = 'settings';
  }
  currentRoute = route;
  if (window.location.hash !== `#${route}`) {
    window.location.hash = route;
  }

  views.forEach((view) => {
    const match = view.dataset.view === route;
    view.hidden = !match;
    view.classList.toggle('is-active', match);
  });

  navItems.forEach((item) => {
    item.classList.toggle('active', item.dataset.route === route);
  });

  if (route === 'calendar') {
    renderCalendar();
    renderSelectedDate();
  }
  if (route === 'insight') {
    renderInsight();
  }
  if (route === 'map') {
    renderMapView();
  }
}

function moveMonth(offset) {
  const next = new Date(calendarCursor.year, calendarCursor.month + offset, 1);
  calendarCursor = { year: next.getFullYear(), month: next.getMonth() };
  renderCalendar();
}

function renderCalendar() {
  const { year, month } = calendarCursor;
  monthLabel.textContent = monthTitle(year, month);
  calendarGrid.innerHTML = '';

  const firstWeekday = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const totalSlots = Math.ceil((firstWeekday + daysInMonth) / 7) * 7;

  for (let slot = 0; slot < totalSlots; slot += 1) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'calendar-day';

    const dayNumber = slot - firstWeekday + 1;
    if (dayNumber < 1 || dayNumber > daysInMonth) {
      button.classList.add('muted');
      button.disabled = true;
      calendarGrid.appendChild(button);
      continue;
    }

    const key = dateKey(year, month, dayNumber);
    const dayRecords = recordsForDate(key);

    if (dayRecords.length > 0) button.classList.add('has-record');
    if (selectedDate === key) button.classList.add('selected');

    button.innerHTML = `
      <span class="day-number">${dayNumber}</span>
      <span class="day-poop">${dayRecords.length > 0 ? '💩' : ''}</span>
      <span class="day-count">${dayRecords.length > 0 ? `${dayRecords.length} 条` : ''}</span>
    `;

    button.addEventListener('click', () => {
      selectedDate = key;
      renderCalendar();
      renderSelectedDate();
    });

    calendarGrid.appendChild(button);
  }
}

function renderSelectedDate() {
  selectedDateList.innerHTML = '';

  if (!selectedDate) {
    selectedDateTitle.textContent = '还没有选择日期';
    selectedDateList.classList.add('empty');
    selectedDateList.innerHTML = buildEmptyState('先点一个日期', '如果那天有记录，就会在这里按时间顺序展示出来。', '🗓️', 'Pick a day');
    return;
  }

  selectedDateTitle.textContent = `${selectedDate} 的记录`;
  const dayRecords = recordsForDate(selectedDate);

  if (dayRecords.length === 0) {
    selectedDateList.classList.add('empty');
    selectedDateList.innerHTML = buildEmptyState('这一天没有记录', '换个日期看看，或者先回首页记一条新的。', '🌤️', 'Quiet day');
    return;
  }

  selectedDateList.classList.remove('empty');
  dayRecords.forEach((record) => {
    const fragment = dayRecordTemplate.content.cloneNode(true);
    fragment.getElementById('dayRecordTime').textContent = `${record.time} · ${record.approx ? '近似位置' : '真实定位'}`;
    fragment.getElementById('dayRecordShape').textContent = formatLabel('shape', record.shape);
    fragment.getElementById('dayRecordLocation').textContent = formatLabel('location', record.location);
    fragment.getElementById('dayRecordMood').textContent = formatLabel('mood', record.mood);
    fragment.getElementById('dayRecordDuration').textContent = formatLabel('duration', record.duration);
    selectedDateList.appendChild(fragment);
  });
}

function applyInsightSelection(content) {
  insightContent = content;
  if (content !== 'overview') {
    analysisDimension = content;
  }
  syncInsightControls();
  renderInsight();
}

function syncInsightControls() {
  contentSelectorButtons.forEach((button) => {
    button.classList.toggle('active', button.dataset.content === insightContent);
  });
  timeFilterButtons.forEach((button) => {
    button.classList.toggle('active', button.dataset.range === insightRange);
  });
  analysisButtons.forEach((button) => {
    button.classList.toggle('active', button.dataset.analysis === analysisDimension);
  });
  analysisTabButtons.forEach((button) => {
    button.classList.toggle('active', button.dataset.analysisTab === analysisDimension);
  });
}

function renderChart(items, dimension) {
  const breakdown = breakdownForDimension(items, dimension);
  const total = breakdown.reduce((sum, item) => sum + item.count, 0);

  if (breakdown.length === 0) {
    chartRing.style.background = '#f2f1ef';
    chartPrimary.textContent = '暂无';
    chartSecondary.textContent = '0 (0%)';
    chartLegend.innerHTML = '<div class="chart-legend-empty">先去记录几条，图表就会亮起来。</div>';
    return;
  }

  const gradient = [];
  let cursor = 0;
  breakdown.forEach((item) => {
    const next = cursor + item.percent;
    gradient.push(`${item.color} ${cursor}% ${next}%`);
    cursor = next;
  });
  chartRing.style.background = `conic-gradient(${gradient.join(', ')})`;

  const leader = breakdown[0];
  chartPrimary.textContent = leader.label;
  chartSecondary.textContent = `${leader.count} (${leader.percent}%)`;
  chartLegend.innerHTML = breakdown
    .map(
      (item) => `
        <div class="legend-item">
          <span class="legend-dot" style="background:${item.color}"></span>
          <span class="legend-label">${item.label}</span>
          <span class="legend-meta">${item.count} / ${total}</span>
        </div>
      `
    )
    .join('');
}

function renderInsight() {
  const filtered = getFilteredRecords(insightRange);
  const total = filtered.length;
  totalCount.textContent = String(total);
  dailyAverage.textContent = total === 0 ? '0' : (total / ({ week: 7, month: 30, halfyear: 183, year: 365 }[insightRange] || 7)).toFixed(1);
  averageDuration.textContent = formatMinutes(average(filtered.map((item) => item.duration)));

  if (total === 0) {
    insightStats.hidden = true;
    insightEmpty.hidden = false;
    insightEmpty.innerHTML = buildEmptyState('暂无数据', `当前是 ${RANGE_LABELS[insightRange]}，先去首页记一条，洞察页就会开始帮你统计。`, '📊', 'No insight yet');
    const persona = resolvePersona([]);
    personaName.textContent = persona.name;
    personaDesc.textContent = persona.desc;
    personaDriver.textContent = persona.driver;
    personaTip.textContent = persona.tip;
    analysisTitle.textContent = ANALYSIS_LABELS[analysisDimension];
    renderChart([], analysisDimension);
    return;
  }

  insightStats.hidden = false;
  insightEmpty.hidden = true;
  analysisTitle.textContent = `${ANALYSIS_LABELS[analysisDimension]} · ${RANGE_LABELS[insightRange]}`;
  renderChart(filtered, analysisDimension);

  const persona = resolvePersona(filtered);
  personaName.textContent = persona.name;
  personaDesc.textContent = persona.desc;
  personaDriver.textContent = `${persona.driver} · ${contentLabels[insightContent] || '总览'}`;
  personaTip.textContent = persona.tip;
}

function ensureMap() {
  if (mapInstance || typeof L === 'undefined') return;
  mapInstance = L.map(mapCanvas, { zoomControl: false }).setView(DEFAULT_CENTER, 15);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap',
  }).addTo(mapInstance);
}

function clearMapMarkers() {
  if (!mapInstance) return;
  mapMarkers.forEach((marker) => marker.remove());
  mapMarkers = [];
}

function renderMapDetail(recordsForMap) {
  mapDetailList.innerHTML = '';
  if (recordsForMap.length === 0) {
    mapDetailTitle.textContent = '还没有位置记录';
    mapDetailList.classList.add('empty');
    mapDetailList.innerHTML = buildEmptyState('暂无位置记录', '下次保存记录时勾选定位，地图页就会开始展示点位。', '📍', 'Map is empty');
    return;
  }

  mapDetailTitle.textContent = `${recordsForMap.length} 条位置记录`;
  mapDetailList.classList.remove('empty');
  recordsForMap.slice(0, 6).forEach((record) => {
    const article = document.createElement('article');
    article.className = 'day-record';
    article.innerHTML = `
      <div class="day-record-time">${record.date} ${record.time}</div>
      <div class="day-record-grid">
        <div class="day-record-chip">${formatLabel('location', record.location)}</div>
        <div class="day-record-chip">${formatLabel('shape', record.shape)}</div>
        <div class="day-record-chip">${formatLabel('duration', record.duration)}</div>
        <div class="day-record-chip">${record.approx ? '近似位置' : '真实定位'}</div>
      </div>
    `;
    mapDetailList.appendChild(article);
  });
}

function renderMapView() {
  renderMapDetail(records.filter((item) => item.coordinates).sort(sortByDateTimeDesc));

  if (!settings.showMap) {
    return;
  }

  ensureMap();
  if (!mapInstance) return;
  clearMapMarkers();

  const mappedRecords = records.filter((item) => Array.isArray(item.coordinates));
  if (mappedRecords.length === 0) {
    mapInstance.setView(DEFAULT_CENTER, 15);
    return;
  }

  mappedRecords.slice(0, 8).forEach((record) => {
    const marker = L.marker(record.coordinates).addTo(mapInstance);
    marker.bindPopup(`
      <strong>${record.date} ${record.time}</strong><br />
      ${formatLabel('location', record.location)}<br />
      ${formatLabel('shape', record.shape)} · ${formatLabel('duration', record.duration)}
    `);
    mapMarkers.push(marker);
  });

  mapInstance.setView(mappedRecords[0].coordinates, mapSatelliteLike ? 17 : 15);
}

function cycleSetting(key, options) {
  const currentIndex = options.indexOf(settings[key]);
  const nextIndex = (currentIndex + 1) % options.length;
  settings[key] = options[nextIndex];
  saveSettings();
  applySettings();
  renderInsight();
}

function applySettings() {
  document.body.dataset.theme = settings.themeColor;
  document.body.dataset.homeStyle = settings.homeStyle;
  document.body.dataset.navStyle = settings.navStyle;
  document.body.dataset.iconStyle = settings.iconStyle;

  themeColorValue.textContent = settings.themeColor;
  homeStyleValue.textContent = settings.homeStyle;
  navStyleValue.textContent = settings.navStyle;
  iconStyleValue.textContent = settings.iconStyle;

  showMapToggle.classList.toggle('on', settings.showMap);
  showHomeCardToggle.classList.toggle('on', settings.showHomeCard);
  mapNavItem.hidden = !settings.showMap;
  homeRecordCard.hidden = !settings.showHomeCard;

  if (!settings.showMap && currentRoute === 'map') {
    setRoute('settings');
  }
}

function toggleBooleanSetting(key) {
  settings[key] = !settings[key];
  saveSettings();
  applySettings();
}

function applyHashRoute() {
  const route = window.location.hash.replace('#', '');
  if (['home', 'calendar', 'insight', 'map', 'settings'].includes(route)) {
    setRoute(route);
    return;
  }
  setRoute('home');
}

function renderAll() {
  renderHomeStats();
  renderRecentRecord();
  renderCalendar();
  renderSelectedDate();
  renderInsight();
  renderMapView();
  applySettings();
}

choiceButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const group = button.dataset.group;
    const value = button.dataset.value;
    formState[group] = value;
    hideError();
    syncChoices();
  });
});

contentSelectorButtons.forEach((button) => {
  button.addEventListener('click', () => {
    applyInsightSelection(button.dataset.content);
  });
});

timeFilterButtons.forEach((button) => {
  button.addEventListener('click', () => {
    insightRange = button.dataset.range;
    syncInsightControls();
    renderInsight();
  });
});

analysisButtons.forEach((button) => {
  button.addEventListener('click', () => {
    analysisDimension = button.dataset.analysis;
    syncInsightControls();
    renderInsight();
  });
});

analysisTabButtons.forEach((button) => {
  button.addEventListener('click', () => {
    analysisDimension = button.dataset.analysisTab;
    syncInsightControls();
    renderInsight();
  });
});

navItems.forEach((item) => {
  item.addEventListener('click', () => {
    setRoute(item.dataset.route);
  });
});

optionButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const setting = button.dataset.setting;
    if (setting === 'themeColor') cycleSetting(setting, THEME_OPTIONS);
    if (setting === 'homeStyle') cycleSetting(setting, HOME_STYLE_OPTIONS);
    if (setting === 'navStyle') cycleSetting(setting, NAV_STYLE_OPTIONS);
    if (setting === 'iconStyle') cycleSetting(setting, ICON_STYLE_OPTIONS);
  });
});

openModalBtn.addEventListener('click', openModal);
closeModalBtn.addEventListener('click', closeModal);
overlay.addEventListener('click', closeModal);
overlay.addEventListener('click', closeConfirmModal);
prevStepBtn.addEventListener('click', goPrev);
nextStepBtn.addEventListener('click', goNext);
saveRecordBtn.addEventListener('click', saveRecord);
prevMonthBtn.addEventListener('click', () => moveMonth(-1));
nextMonthBtn.addEventListener('click', () => moveMonth(1));
clearDataBtn.addEventListener('click', openConfirmModal);
closeConfirmBtn.addEventListener('click', closeConfirmModal);
cancelClearBtn.addEventListener('click', closeConfirmModal);
confirmClearBtn.addEventListener('click', () => {
  clearAllRecords();
  closeConfirmModal();
  setRoute('home');
});
toggleMapBtn.addEventListener('click', () => toggleBooleanSetting('showMap'));
toggleHomeCardBtn.addEventListener('click', () => toggleBooleanSetting('showHomeCard'));
locateLatestBtn.addEventListener('click', () => {
  const latest = records.find((record) => Array.isArray(record.coordinates));
  if (latest && mapInstance) {
    mapInstance.setView(latest.coordinates, 17);
  }
});
toggleMap3dBtn.addEventListener('click', () => {
  mapSatelliteLike = !mapSatelliteLike;
  toggleMap3dBtn.classList.toggle('active', mapSatelliteLike);
  renderMapView();
});
window.addEventListener('hashchange', applyHashRoute);

syncInsightControls();
renderAll();
applyHashRoute();
