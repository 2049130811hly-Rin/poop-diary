const STORAGE_KEY = 'bingo.energy.v2';
const LEGACY_KEY = 'bingo.energy.v1';

const GRID_SIZE = 5;
const CELL_COUNT = GRID_SIZE * GRID_SIZE;
const RING_CIRCUMFERENCE = 302;
const LONG_PRESS_MS = 650;

const gridEl = document.getElementById('grid');
const randomizeBtn = document.getElementById('randomizeBtn');
const resetBtn = document.getElementById('resetBtn');
const openSheetBtn = document.getElementById('openSheetBtn');

const pctText = document.getElementById('pctText');
const headline = document.getElementById('headline');
const desc = document.getElementById('desc');
const ringFg = document.querySelector('.ring-fg');
const dateLabel = document.getElementById('dateLabel');
const lineHint = document.getElementById('lineHint');
const lineCountEl = document.getElementById('lineCount');

const toast = document.getElementById('toast');
const toastTitle = document.getElementById('toastTitle');
const toastDesc = document.getElementById('toastDesc');
const toastClose = document.getElementById('toastClose');

const overlay = document.getElementById('overlay');
const sheet = document.getElementById('sheet');
const sheetClose = document.getElementById('sheetClose');
const sheetTaskName = document.getElementById('sheetTaskName');
const toggleDoneBtn = document.getElementById('toggleDoneBtn');
const toggleCoreBtn = document.getElementById('toggleCoreBtn');
const startBtn = document.getElementById('startBtn');
const stopBtn = document.getElementById('stopBtn');
const autoBreakBtn = document.getElementById('autoBreakBtn');
const stepsEl = document.getElementById('steps');
const breakSummary = document.getElementById('breakSummary');
const stepCountEl = document.getElementById('stepCount');
const stepDoneCountEl = document.getElementById('stepDoneCount');
const stepPlannedEl = document.getElementById('stepPlanned');
const stepRemainEl = document.getElementById('stepRemain');
const timerClock = document.getElementById('timerClock');
const timerSub = document.getElementById('timerSub');
const timerFoot = document.getElementById('timerFoot');
const focusTodayEl = document.getElementById('focusToday');
const timerModeChips = Array.from(document.querySelectorAll('.timer-controls .chip'));
const presetBtns = Array.from(document.querySelectorAll('#timerPresets .pill'));
const timerPresets = document.getElementById('timerPresets');
const recoveryEmpty = document.getElementById('recoveryEmpty');
const recoveryBody = document.getElementById('recoveryBody');
const recoveryStep = document.getElementById('recoveryStep');
const recoveryReason = document.getElementById('recoveryReason');
const recoveryHint = document.getElementById('recoveryHint');
const recoveryAt = document.getElementById('recoveryAt');
const markInterruptedBtn = document.getElementById('markInterruptedBtn');
const resumeTaskBtn = document.getElementById('resumeTaskBtn');
const reasonPills = Array.from(document.querySelectorAll('.reason-pill'));

const confettiCanvas = document.getElementById('confetti');
const confettiCtx = confettiCanvas.getContext('2d');

const TASK_POOL = [
  '学习 25 分钟',
  '整理书桌',
  '打扫房间 10 分钟',
  '晒太阳 5 分钟',
  '喝一杯水',
  '出门走路 10 分钟',
  '拉伸 3 分钟',
  '深呼吸 10 次',
  '写下 3 件感恩',
  '写一句今日目标',
  '清理手机相册 20 张',
  '关掉一个不必要的通知',
  '读书 10 页',
  '整理衣服一小堆',
  '洗一个杯子/碗',
  '准备明天的衣服',
  '做一次护肤流程',
  '补充蛋白质',
  '吃一份水果',
  '午睡 20 分钟',
  '早睡提前 20 分钟',
  '写 5 行日记',
  '复盘今天 2 分钟',
  '对自己说一句鼓励',
  '给朋友发一句问候',
  '听一首歌放空',
  '收拾床铺',
  '倒垃圾',
  '给植物浇水',
  '回复一条消息',
  '清洗餐具',
  '整理背包/包里',
  '补一个维生素',
  '做 10 个深蹲',
  '练字 3 分钟',
  '写 1 个灵感点子',
  '关机休息 10 分钟',
  '清空桌面文件',
  '学习一个新单词',
  '看窗外发呆 1 分钟',
  '泡脚 10 分钟',
  '洗头/洗澡',
  '整理一个抽屉',
  '给自己泡杯茶',
  '把水杯装满',
  '把垃圾分类',
  '擦一下镜子',
  '清理厨房台面',
  '整理床头柜',
  '背诵 5 分钟',
  '读一篇文章',
  '写一封未发送的信',
  '做 1 次冥想',
  '走楼梯 1 层',
  '把东西放回原位',
  '关掉 3 个浏览器标签',
  '开窗通风 5 分钟',
  '伸个懒腰',
  '按时吃药/补剂',
  '记录今日情绪',
  '列出 3 个待办',
  '只做最难任务的第一步',
  '删掉 10 个无用 App',
  '整理一份资料',
  '洗衣服/晾衣服',
  '拖地 5 分钟',
  '练听力 10 分钟',
  '写邮件草稿',
  '备份一个重要文件',
  '做一次眼保健操',
  '离开屏幕 3 分钟',
  '擦桌子',
  '清理洗手台',
  '收纳一小袋杂物',
  '把便签整理一下',
  '把快递盒处理掉',
  '学习一段视频',
  '做 10 个俯卧撑(可跪姿)',
  '写下一个你想要的未来',
  '整理购物清单',
  '准备一份健康零食',
  '检查一次日程',
  '把房间灯光调柔和',
];

const MESSAGES = [
  { h: '完美完成，能量满满', d: '你做到了。接下来只要保持这个节奏。' },
  { h: '连成一线了', d: '稳定地完成，就会越来越轻松。' },
  { h: '今天进度 100%', d: '你在用行动照顾自己。' },
  { h: '太强了', d: '完成不是一口气，是一次次小赢。' },
  { h: '漂亮的一局', d: '给自己一个小奖励吧。' },
];

let state = loadState();
let prevLineCount = 0;
let timerRaf = 0;

function todayKey() {
  const now = new Date();
  return now.toISOString().slice(0, 10);
}

function formatTodayLabel(dateStr) {
  const parts = String(dateStr || '').split('-');
  if (parts.length !== 3) return String(dateStr || '');
  return `${parts[0]}.${parts[1]}.${parts[2]}`;
}

function clampInt(value, min, max, fallback) {
  if (!Number.isFinite(value)) return fallback;
  return Math.max(min, Math.min(max, Math.floor(value)));
}

function makeId() {
  return Math.random().toString(36).slice(2, 10);
}

function shuffle(list) {
  const arr = [...list];
  for (let i = arr.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function pickTasks() {
  const unique = Array.from(new Set(TASK_POOL));
  const bag = shuffle(unique);
  if (bag.length >= CELL_COUNT) return bag.slice(0, CELL_COUNT);
  const out = [];
  while (out.length < CELL_COUNT) out.push(bag[out.length % bag.length]);
  return out;
}

function makeDefaultState() {
  return {
    day: todayKey(),
    tasks: pickTasks().map((text) => ({
      text,
      steps: [],
      interruption: null,
      selectedReason: '',
    })),
    done: Array.from({ length: CELL_COUNT }, () => false),
    priorityIndex: null,
    lastIndex: null,
    focus: {
      locked: false,
      index: null,
      timer: {
        mode: 'countdown',
        presetSec: 1500,
        running: false,
        startedAt: 0,
        baseRemainingSec: 1500,
        baseElapsedSec: 0,
        lastAccAt: 0,
        notified: false,
      },
    },
    stats: {
      day: todayKey(),
      focusSeconds: 0,
    },
  };
}

function normalizeState(parsed) {
  const next = { ...makeDefaultState(), ...parsed };

  // Backward compat: tasks might be string[].
  if (Array.isArray(next.tasks) && typeof next.tasks[0] === 'string') {
    next.tasks = next.tasks.map((text) => ({ text, steps: [] }));
  }
  if (!Array.isArray(next.tasks) || next.tasks.length !== CELL_COUNT) {
    next.tasks = makeDefaultState().tasks;
  }
  next.tasks = next.tasks.map((t) => ({
    text: typeof t?.text === 'string' ? t.text : '未命名任务',
    steps: normalizeSteps(Array.isArray(t?.steps) ? t.steps : []),
    interruption: normalizeInterruption(t?.interruption),
    selectedReason: typeof t?.selectedReason === 'string' ? t.selectedReason : '',
  }));

  if (!Array.isArray(next.done) || next.done.length !== CELL_COUNT) {
    next.done = Array.from({ length: CELL_COUNT }, () => false);
  }

  if (typeof next.priorityIndex !== 'number') next.priorityIndex = null;
  if (next.priorityIndex !== null && (next.priorityIndex < 0 || next.priorityIndex >= CELL_COUNT)) {
    next.priorityIndex = null;
  }

  if (typeof next.lastIndex !== 'number') next.lastIndex = null;
  if (next.lastIndex !== null && (next.lastIndex < 0 || next.lastIndex >= CELL_COUNT)) {
    next.lastIndex = null;
  }

  if (!next.focus || typeof next.focus !== 'object') next.focus = makeDefaultState().focus;
  if (!next.focus.timer || typeof next.focus.timer !== 'object') next.focus.timer = makeDefaultState().focus.timer;
  if (typeof next.focus.locked !== 'boolean') next.focus.locked = false;
  if (typeof next.focus.index !== 'number') next.focus.index = null;
  if (next.focus.index !== null && (next.focus.index < 0 || next.focus.index >= CELL_COUNT)) {
    next.focus.index = null;
  }

  const mode = next.focus.timer.mode;
  next.focus.timer.mode = mode === 'countup' ? 'countup' : 'countdown';
  next.focus.timer.presetSec = clampInt(next.focus.timer.presetSec, 60, 7200, 1500);
  next.focus.timer.running = Boolean(next.focus.timer.running);
  next.focus.timer.startedAt = Number(next.focus.timer.startedAt) || 0;
  next.focus.timer.baseRemainingSec = clampInt(
    Number(next.focus.timer.baseRemainingSec),
    60,
    7200,
    next.focus.timer.presetSec
  );
  next.focus.timer.baseElapsedSec = clampInt(Number(next.focus.timer.baseElapsedSec), 0, 86400, 0);
  next.focus.timer.lastAccAt = Number(next.focus.timer.lastAccAt) || 0;
  next.focus.timer.notified = Boolean(next.focus.timer.notified);

  if (!next.stats || typeof next.stats !== 'object') next.stats = makeDefaultState().stats;
  if (next.stats.day !== todayKey()) {
    next.stats.day = todayKey();
    next.stats.focusSeconds = 0;
  }
  next.stats.focusSeconds = clampInt(Number(next.stats.focusSeconds), 0, 86400 * 7, 0);

  return next;
}

function normalizeSteps(steps) {
  return steps.map((step) => ({
    id: typeof step?.id === 'string' ? step.id : makeId(),
    text: typeof step?.text === 'string' ? step.text : '未命名步骤',
    done: Boolean(step?.done),
    minutes: clampInt(Number(step?.minutes), 2, 180, 10),
    children: Array.isArray(step?.children)
      ? step.children.map((child) => ({
          id: typeof child?.id === 'string' ? child.id : makeId(),
          text: typeof child?.text === 'string' ? child.text : '未命名子步骤',
          done: Boolean(child?.done),
          minutes: clampInt(Number(child?.minutes), 1, 90, 5),
        }))
      : [],
  }));
}

function normalizeInterruption(interruption) {
  if (!interruption || typeof interruption !== 'object') return null;
  return {
    stepText: typeof interruption.stepText === 'string' ? interruption.stepText : '',
    reason: typeof interruption.reason === 'string' ? interruption.reason : '',
    resumeHint: typeof interruption.resumeHint === 'string' ? interruption.resumeHint : '',
    at: typeof interruption.at === 'number' ? interruption.at : 0,
    active: interruption.active !== false,
  };
}

function loadState() {
  try {
    let raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      // Best-effort migrate from v1 (string tasks + done array).
      const legacyRaw = localStorage.getItem(LEGACY_KEY);
      if (legacyRaw) {
        try {
          const legacy = JSON.parse(legacyRaw);
          if (legacy && Array.isArray(legacy.tasks) && Array.isArray(legacy.done)) {
            const migrated = makeDefaultState();
            migrated.day = typeof legacy.day === 'string' ? legacy.day : todayKey();
            migrated.tasks = legacy.tasks.slice(0, CELL_COUNT).map((t) => ({
              text: typeof t === 'string' ? t : '未命名任务',
              steps: [],
            }));
            while (migrated.tasks.length < CELL_COUNT) migrated.tasks.push({ text: '未命名任务', steps: [] });
            migrated.done = legacy.done.slice(0, CELL_COUNT).map((x) => Boolean(x));
            raw = JSON.stringify(migrated);
          }
        } catch {
          // ignore legacy failures
        }
      }
    }
    if (!raw) return makeDefaultState();
    const parsed = JSON.parse(raw);
    const normalized = normalizeState(parsed);

    if (normalized.day !== todayKey()) {
      // New day: clear completions and timer/locks; keep task set and core selection.
      normalized.day = todayKey();
      normalized.done = normalized.done.map(() => false);
      normalized.lastIndex = null;
      normalized.focus.locked = false;
      normalized.focus.index = null;
      normalized.focus.timer.running = false;
      normalized.focus.timer.startedAt = 0;
      normalized.focus.timer.lastAccAt = 0;
      normalized.focus.timer.notified = false;
    }

    return normalized;
  } catch {
    return makeDefaultState();
  }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function tileColorClass(index) {
  const mod = index % 5;
  if (mod === 0) return 'var(--tile-1)';
  if (mod === 1) return 'var(--tile-2)';
  if (mod === 2) return 'var(--tile-3)';
  if (mod === 3) return 'var(--tile-4)';
  return 'var(--tile-5)';
}

function pickMessage() {
  return MESSAGES[Math.floor(Math.random() * MESSAGES.length)];
}

function showToast(payload) {
  toastTitle.textContent = payload.title;
  toastDesc.textContent = payload.detail;
  toast.hidden = false;
  window.clearTimeout(showToast._t);
  showToast._t = window.setTimeout(() => {
    toast.hidden = true;
  }, 3400);
}

function setProgress(percent, hasLine) {
  const clamped = Math.max(0, Math.min(100, percent));
  pctText.textContent = `${clamped}%`;
  ringFg.style.strokeDashoffset = String(
    RING_CIRCUMFERENCE - (RING_CIRCUMFERENCE * clamped) / 100
  );
  ringFg.style.stroke = hasLine ? 'rgba(47, 158, 106, 0.92)' : 'rgba(124, 114, 243, 0.92)';
}

function countDone() {
  return state.done.filter(Boolean).length;
}

function computeLines() {
  const lines = [];
  for (let r = 0; r < GRID_SIZE; r += 1) {
    const idxs = [];
    for (let c = 0; c < GRID_SIZE; c += 1) idxs.push(r * GRID_SIZE + c);
    if (idxs.every((i) => state.done[i])) lines.push({ type: 'row', index: r });
  }
  for (let c = 0; c < GRID_SIZE; c += 1) {
    const idxs = [];
    for (let r = 0; r < GRID_SIZE; r += 1) idxs.push(r * GRID_SIZE + c);
    if (idxs.every((i) => state.done[i])) lines.push({ type: 'col', index: c });
  }
  return lines;
}

prevLineCount = computeLines().length;

function isPriorityActive() {
  return state.priorityIndex !== null && !state.done[state.priorityIndex];
}

function isFocusLocked() {
  return Boolean(state.focus.locked && state.focus.index !== null && state.focus.timer.running);
}

function isCellLocked(index) {
  if (isPriorityActive() && index !== state.priorityIndex) return true;
  if (isFocusLocked() && index !== state.focus.index) return true;
  return false;
}

function currentIndexForSheet() {
  if (isPriorityActive()) return state.priorityIndex;
  if (state.focus.index !== null) return state.focus.index;
  if (state.lastIndex !== null) return state.lastIndex;
  return null;
}

function formatClock(sec) {
  const s = Math.max(0, Math.floor(sec));
  const mm = String(Math.floor(s / 60)).padStart(2, '0');
  const ss = String(s % 60).padStart(2, '0');
  return `${mm}:${ss}`;
}

function openSheet() {
  overlay.hidden = false;
  sheet.hidden = false;
  syncSheet();
}

function closeSheet() {
  overlay.hidden = true;
  sheet.hidden = true;
}

function togglePriority(index) {
  if (index < 0 || index >= CELL_COUNT) return;

  if (state.focus.timer.running && state.focus.index !== null && state.focus.index !== index) {
    showToast({ title: '专注中', detail: '正在锁定专注，先停止再切换能量核心。' });
    return;
  }

  if (state.priorityIndex === index) {
    state.priorityIndex = null;
    saveState();
    render();
    showToast({ title: '已取消能量核心', detail: '现在可以自由选择任务。' });
    return;
  }

  if (isPriorityActive()) {
    showToast({ title: '核心锁定中', detail: '先完成当前能量核心，或长按核心取消。' });
    return;
  }

  state.priorityIndex = index;
  saveState();
  render();
  showToast({ title: '已设为能量核心', detail: '未完成核心前，其它格子会被锁定。' });
}

function setLastIndex(index) {
  state.lastIndex = index;
  saveState();
}

function derivedTimer() {
  const timer = state.focus.timer;
  if (!timer.running) {
    if (timer.mode === 'countdown') return { mode: 'countdown', remaining: timer.presetSec, elapsed: 0 };
    return { mode: 'countup', remaining: timer.presetSec, elapsed: 0 };
  }
  const now = Date.now();
  const elapsed = Math.max(0, Math.floor((now - timer.startedAt) / 1000));
  if (timer.mode === 'countdown') {
    return { mode: 'countdown', remaining: Math.max(0, timer.baseRemainingSec - elapsed), elapsed };
  }
  return { mode: 'countup', remaining: timer.presetSec, elapsed: timer.baseElapsedSec + elapsed };
}

function tickTimer(forceSave) {
  const timer = state.focus.timer;
  if (!timer.running) return;
  const now = Date.now();
  if (!timer.lastAccAt) timer.lastAccAt = now;
  const deltaSec = Math.floor((now - timer.lastAccAt) / 1000);
  if (deltaSec > 0) {
    state.stats.focusSeconds += deltaSec;
    timer.lastAccAt += deltaSec * 1000;
    if (forceSave) saveState();
  }
}

function stopFocusTimer(opts) {
  const options = opts || { unlock: true, silent: false };
  const timer = state.focus.timer;
  const activeIndex = state.focus.index;
  if (!timer.running) {
    if (options.unlock) state.focus.locked = false;
    return;
  }
  tickTimer(true);
  timer.running = false;
  timer.startedAt = 0;
  timer.lastAccAt = 0;
  timer.notified = false;
  if (options.unlock) state.focus.locked = false;
  saveState();
  render();
  if (
    activeIndex !== null &&
    !options.skipRecovery &&
    !state.done[activeIndex] &&
    !state.tasks[activeIndex].interruption
  ) {
    markInterrupted(activeIndex, state.tasks[activeIndex].selectedReason || '脑子乱了，需要缓一下');
    return;
  }
  if (!options.silent) showToast({ title: '已停止', detail: '保持节奏，下一步也会更轻松。' });
}

function startFocusTimer(index) {
  const timer = state.focus.timer;
  const now = Date.now();
  state.focus.index = index;
  state.focus.locked = true;
  state.lastIndex = index;
  if (state.tasks[index].interruption) {
    state.tasks[index].interruption.active = false;
  }
  timer.running = true;
  timer.startedAt = now;
  timer.lastAccAt = now;
  timer.notified = false;
  if (timer.mode === 'countdown') {
    timer.baseRemainingSec = timer.presetSec;
    timer.baseElapsedSec = 0;
  } else {
    timer.baseElapsedSec = 0;
    timer.baseRemainingSec = timer.presetSec;
  }
  saveState();
  render();
}

function ensureSteps(index) {
  const task = state.tasks[index];
  if (!Array.isArray(task.steps)) task.steps = [];
}

function flattenSteps(steps) {
  const out = [];
  steps.forEach((step) => {
    out.push({ kind: 'step', item: step });
    if (Array.isArray(step.children)) {
      step.children.forEach((child) => out.push({ kind: 'child', item: child, parent: step }));
    }
  });
  return out;
}

function stepStats(steps) {
  const flat = flattenSteps(Array.isArray(steps) ? steps : []);
  const total = flat.length;
  const done = flat.filter((entry) => entry.item.done).length;
  const plannedMin = flat.reduce((sum, entry) => sum + (entry.item.minutes || 0), 0);
  const remainMin = flat.reduce((sum, entry) => sum + (entry.item.done ? 0 : entry.item.minutes || 0), 0);
  return { total, done, plannedMin, remainMin };
}

function firstUndoneAction(steps) {
  for (const step of steps) {
    if (!step.done) return { text: step.text, minutes: step.minutes || 10 };
    if (Array.isArray(step.children)) {
      const child = step.children.find((item) => !item.done);
      if (child) return { text: child.text, minutes: child.minutes || 5 };
    }
  }
  return null;
}

function formatMinutes(min) {
  return `${Math.max(0, Math.round(min || 0))} 分钟`;
}

function formatDateTime(ts) {
  if (!ts) return '--';
  const date = new Date(ts);
  const hh = String(date.getHours()).padStart(2, '0');
  const mm = String(date.getMinutes()).padStart(2, '0');
  return `${date.getMonth() + 1}/${date.getDate()} ${hh}:${mm}`;
}

function suggestSteps(taskText) {
  const base = [
    ['写下完成标准(一句话)', 5],
    ['准备需要的材料/工具', 5],
    ['先做 2 分钟热身', 3],
    ['完成最小的一步', 10],
    ['收尾并整理', 5],
  ];
  const t = String(taskText || '').toLowerCase();
  const extra = [];
  if (t.includes('学习') || t.includes('读') || t.includes('听')) {
    extra.push(['确认本次要点(3 个)', 8]);
    extra.push(['做 1 道小练习', 12]);
    extra.push(['用一句话复述', 5]);
  }
  if (t.includes('打扫') || t.includes('整理') || t.includes('清理') || t.includes('收纳')) {
    extra.push(['先处理最显眼的一堆', 8]);
    extra.push(['丢弃/归位 10 件物品', 10]);
    extra.push(['擦拭一个平面', 6]);
  }
  if (t.includes('运动') || t.includes('走') || t.includes('拉伸')) {
    extra.push(['喝一口水', 2]);
    extra.push(['设置一个小目标(例如 5 分钟)', 3]);
    extra.push(['做完后放松 30 秒', 2]);
  }
  return [...base, ...extra].slice(0, 7).map(([text, minutes]) => ({
    id: makeId(),
    text,
    done: false,
    minutes,
    children: [],
  }));
}

function allStepsDone(steps) {
  if (!Array.isArray(steps) || steps.length === 0) return false;
  return steps.every((s) => {
    const children = Array.isArray(s.children) ? s.children : [];
    const childrenDone = children.length === 0 ? true : children.every((c) => Boolean(c.done));
    return Boolean(s.done) && childrenDone;
  });
}

function setTaskDone(index, done) {
  state.done[index] = done;

  // If marking as done, also mark all steps as done.
  if (done) {
    ensureSteps(index);
    state.tasks[index].steps.forEach((s) => {
      s.done = true;
      if (Array.isArray(s.children)) s.children.forEach((c) => (c.done = true));
    });
    state.tasks[index].interruption = null;
  }

  // Auto unlock focus when target finished.
  if (done && state.focus.index === index && state.focus.locked) {
    stopFocusTimer({ unlock: true, silent: true });
  }

  saveState();
  render();

  if (done && state.priorityIndex === index) {
    showToast({ title: '核心完成', detail: '很好，现在其它任务都解锁了。' });
  }
}

function markInterrupted(index, reason) {
  const task = state.tasks[index];
  ensureSteps(index);
  const nextAction = firstUndoneAction(task.steps) || { text: task.text, minutes: 5 };
  task.selectedReason = reason || task.selectedReason || '突然有事插进来';
  task.interruption = {
    stepText: nextAction.text,
    reason: task.selectedReason,
    resumeHint: `回来后先做“${nextAction.text}” ${formatMinutes(nextAction.minutes)}`,
    at: Date.now(),
    active: true,
  };
  if (state.focus.index === index && state.focus.timer.running) {
    stopFocusTimer({ unlock: true, silent: true });
  }
  saveState();
  syncSheet();
  showToast({ title: '中断点已记住', detail: '不用重找状态，回来就按提示继续。' });
}

function resumeInterruptedTask(index) {
  const task = state.tasks[index];
  if (!task.interruption) return;
  state.lastIndex = index;
  task.interruption.active = false;
  saveState();
  openSheet();
  syncSheet();
  showToast({ title: '继续就好', detail: task.interruption.resumeHint || '从最小的一步重新接上。' });
}

function renderSteps() {
  const idx = currentIndexForSheet();
  stepsEl.innerHTML = '';
  if (idx === null) return;
  ensureSteps(idx);
  const steps = state.tasks[idx].steps;

  if (!Array.isArray(steps) || steps.length === 0) {
    const empty = document.createElement('div');
    empty.style.color = 'rgba(27, 26, 31, 0.62)';
    empty.style.fontSize = '12px';
    empty.textContent = '还没有拆解。点“一键拆解”开始。';
    stepsEl.appendChild(empty);
    return;
  }

  steps.forEach((step) => {
    const stepWrap = document.createElement('div');
    stepWrap.className = 'step';

    const top = document.createElement('div');
    top.className = 'step-top';

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = Boolean(step.done);
    cb.addEventListener('change', () => {
      step.done = cb.checked;
      if (step.done && Array.isArray(step.children)) step.children.forEach((c) => (c.done = true));
      saveState();
      if (allStepsDone(state.tasks[idx].steps)) setTaskDone(idx, true);
      syncSheet();
    });

    const text = document.createElement('div');
    text.className = `step-text${step.done ? ' done' : ''}`;
    text.textContent = step.text;

    const eta = document.createElement('div');
    eta.className = 'step-eta';
    eta.textContent = formatMinutes(step.minutes);

    const minis = document.createElement('div');
    minis.className = 'step-mini';

    const splitBtn = document.createElement('button');
    splitBtn.type = 'button';
    splitBtn.className = 'mini';
    splitBtn.textContent = '继续拆';
    splitBtn.addEventListener('click', () => {
      if (!Array.isArray(step.children)) step.children = [];
      if (step.children.length === 0) {
        step.children = suggestSteps(step.text).slice(0, 4).map((s) => ({
          id: s.id,
          text: s.text,
          done: false,
          minutes: Math.max(2, Math.round((s.minutes || 5) / 2)),
        }));
      }
      saveState();
      syncSheet();
    });

    minis.appendChild(splitBtn);
    top.appendChild(cb);
    top.appendChild(text);
    top.appendChild(eta);
    top.appendChild(minis);
    stepWrap.appendChild(top);

    const children = Array.isArray(step.children) ? step.children : [];
    if (children.length > 0) {
      const childWrap = document.createElement('div');
      childWrap.className = 'children';
      children.forEach((c) => {
        const row = document.createElement('div');
        row.className = 'child';
        const ccb = document.createElement('input');
        ccb.type = 'checkbox';
        ccb.checked = Boolean(c.done);
        ccb.addEventListener('change', () => {
          c.done = ccb.checked;
          if (children.every((x) => x.done)) step.done = true;
          saveState();
          if (allStepsDone(state.tasks[idx].steps)) setTaskDone(idx, true);
          syncSheet();
        });
        const ctext = document.createElement('div');
        ctext.textContent = c.text;
        const ceta = document.createElement('div');
        ceta.className = 'child-eta';
        ceta.textContent = formatMinutes(c.minutes);
        row.appendChild(ccb);
        row.appendChild(ctext);
        row.appendChild(ceta);
        childWrap.appendChild(row);
      });
      stepWrap.appendChild(childWrap);
    }

    stepsEl.appendChild(stepWrap);
  });
}

function syncSheet() {
  const idx = currentIndexForSheet();
  const has = idx !== null;
  const timer = state.focus.timer;
  const priorityActive = isPriorityActive();
  const task = has ? state.tasks[idx] : null;

  openSheetBtn.title = has ? '打开当前任务面板' : '先点一个格子作为当前任务';
  sheetTaskName.textContent = has ? task.text : '未选择';

  toggleDoneBtn.disabled = !has || isCellLocked(idx);
  toggleCoreBtn.disabled = !has;
  autoBreakBtn.disabled = !has || isCellLocked(idx);
  markInterruptedBtn.disabled = !has;
  resumeTaskBtn.disabled = !has || !task?.interruption;

  if (!has) {
    toggleDoneBtn.textContent = '标记今日完成';
    toggleCoreBtn.textContent = '设为能量核心';
  } else {
    toggleDoneBtn.textContent = state.done[idx] ? '取消今日完成' : '标记今日完成';
    toggleCoreBtn.textContent = state.priorityIndex === idx ? '取消能量核心' : '设为能量核心';
  }

  timerModeChips.forEach((chip) => {
    chip.classList.toggle('active', chip.dataset.mode === timer.mode);
  });
  timerPresets.style.display = timer.mode === 'countdown' ? 'flex' : 'none';
  presetBtns.forEach((btn) => {
    btn.classList.toggle('active', Number(btn.dataset.sec) === timer.presetSec);
  });

  startBtn.disabled = !has || isCellLocked(idx) || (priorityActive && idx !== state.priorityIndex);
  stopBtn.disabled = !timer.running;

  const d = derivedTimer();
  timerClock.textContent = d.mode === 'countdown' ? formatClock(d.remaining) : formatClock(d.elapsed);
  timerSub.textContent = timer.running ? `锁定中 · ${timer.mode === 'countdown' ? '倒计时' : '正计时'}` : '未开始';

  focusTodayEl.textContent = String(state.stats.focusSeconds);
  timerFoot.hidden = false;

  if (has) {
    const stats = stepStats(task.steps);
    const hasSteps = stats.total > 0;
    breakSummary.hidden = !hasSteps;
    if (hasSteps) {
      stepCountEl.textContent = String(stats.total);
      stepDoneCountEl.textContent = String(stats.done);
      stepPlannedEl.textContent = formatMinutes(stats.plannedMin);
      stepRemainEl.textContent = formatMinutes(stats.remainMin);
    }

    reasonPills.forEach((pill) => {
      pill.classList.toggle('active', pill.dataset.reason === task.selectedReason);
    });

    if (task.interruption) {
      recoveryEmpty.hidden = true;
      recoveryBody.hidden = false;
      recoveryStep.textContent = task.interruption.stepText || '未记录';
      recoveryReason.textContent = task.interruption.reason || '未记录';
      recoveryHint.textContent = task.interruption.resumeHint || '未记录';
      recoveryAt.textContent = formatDateTime(task.interruption.at);
      resumeTaskBtn.textContent = task.interruption.active ? '按提示继续' : '再看一次提示';
    } else {
      recoveryEmpty.hidden = false;
      recoveryBody.hidden = true;
      resumeTaskBtn.textContent = '按提示继续';
    }
  } else {
    breakSummary.hidden = true;
    recoveryEmpty.hidden = false;
    recoveryBody.hidden = true;
  }

  renderSteps();
}

function resizeConfetti() {
  const dpr = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
  confettiCanvas.width = Math.floor(window.innerWidth * dpr);
  confettiCanvas.height = Math.floor(window.innerHeight * dpr);
  confettiCanvas.style.width = `${window.innerWidth}px`;
  confettiCanvas.style.height = `${window.innerHeight}px`;
  confettiCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

function launchConfetti() {
  resizeConfetti();
  const colors = ['#7c72f3', '#2f9e6a', '#f59f00', '#ff5c8a', '#3a86ff'];
  const particles = [];
  const count = Math.floor(140 + Math.random() * 80);

  for (let i = 0; i < count; i += 1) {
    const angle = (-Math.PI / 2) + (Math.random() - 0.5) * (Math.PI / 1.9);
    const speed = 6 + Math.random() * 7;
    particles.push({
      x: window.innerWidth * (0.2 + Math.random() * 0.6),
      y: window.innerHeight * (0.25 + Math.random() * 0.18),
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
      g: 0.18 + Math.random() * 0.14,
      w: 6 + Math.random() * 10,
      h: 4 + Math.random() * 10,
      rot: Math.random() * Math.PI,
      vr: (Math.random() - 0.5) * 0.22,
      color: colors[Math.floor(Math.random() * colors.length)],
      life: 0,
      ttl: 120 + Math.floor(Math.random() * 60),
    });
  }

  let raf = 0;
  function frame() {
    confettiCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    particles.forEach((p) => {
      p.life += 1;
      p.vy += p.g;
      p.x += p.vx;
      p.y += p.vy;
      p.rot += p.vr;
      const fade = Math.max(0, Math.min(1, 1 - p.life / p.ttl));
      confettiCtx.save();
      confettiCtx.translate(p.x, p.y);
      confettiCtx.rotate(p.rot);
      confettiCtx.globalAlpha = fade;
      confettiCtx.fillStyle = p.color;
      confettiCtx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
      confettiCtx.restore();
    });

    const alive = particles.some((p) => p.life < p.ttl);
    if (alive) {
      raf = window.requestAnimationFrame(frame);
    } else {
      confettiCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);
      window.cancelAnimationFrame(raf);
    }
  }

  window.cancelAnimationFrame(timerRaf);
  timerRaf = window.requestAnimationFrame(frame);
}

function render() {
  dateLabel.textContent = `今天 · ${formatTodayLabel(todayKey())}`;

  const doneCount = countDone();
  const lines = computeLines();
  const hasLine = lines.length > 0;
  const lineCount = lines.length;

  const percent = hasLine ? 100 : Math.round((doneCount / CELL_COUNT) * 100);
  setProgress(percent, hasLine);

  if (hasLine) {
    const msg = pickMessage();
    headline.textContent = msg.h;
    desc.textContent = msg.d;
    lineHint.hidden = false;
    lineCountEl.textContent = String(lineCount);
  } else {
    headline.textContent = doneCount === 0 ? '从最小的一步开始' : '稳稳推进';
    desc.textContent = '点格子标记“今日完成”。连成任意一行或一列，即达成 100%。';
    lineHint.hidden = true;
  }

  if (lineCount > prevLineCount) {
    const msg = pickMessage();
    showToast({ title: '能量连线成功', detail: msg.d });
    launchConfetti();
  }
  prevLineCount = lineCount;

  gridEl.innerHTML = '';
  for (let i = 0; i < CELL_COUNT; i += 1) {
    const btn = document.createElement('button');
    btn.type = 'button';

    const locked = isCellLocked(i);
    const isPriority = state.priorityIndex === i && !state.done[i];
    btn.className = `cell${state.done[i] ? ' done' : ''}${locked ? ' locked' : ''}${
      isPriority ? ' priority' : ''
    }`;

    btn.style.background = tileColorClass(i);
    btn.setAttribute('role', 'gridcell');
    btn.setAttribute('aria-rowindex', String(Math.floor(i / GRID_SIZE) + 1));
    btn.setAttribute('aria-colindex', String((i % GRID_SIZE) + 1));
    btn.setAttribute('aria-pressed', state.done[i] ? 'true' : 'false');
    btn.setAttribute('title', locked ? '已锁定' : state.done[i] ? '点击取消完成' : '点击标记完成');

    const span = document.createElement('span');
    span.className = 'text';
    span.textContent = state.tasks[i].text;
    btn.appendChild(span);

    // Long-press to set PriorityLock (energy core).
    let lpTimer = 0;
    let lpTriggered = false;
    const clearLp = () => {
      window.clearTimeout(lpTimer);
      lpTimer = 0;
    };

    btn.addEventListener('pointerdown', (e) => {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      lpTriggered = false;
      clearLp();
      lpTimer = window.setTimeout(() => {
        lpTriggered = true;
        togglePriority(i);
      }, LONG_PRESS_MS);
    });
    btn.addEventListener('pointerup', () => clearLp());
    btn.addEventListener('pointercancel', () => clearLp());
    btn.addEventListener('pointerleave', () => clearLp());

    btn.addEventListener('click', () => {
      setLastIndex(i);
      if (locked) {
        if (lpTriggered) return;
        if (isPriorityActive()) {
          showToast({ title: '先搞定能量核心', detail: '长按核心可以取消，但建议先完成它。' });
        } else if (isFocusLocked()) {
          showToast({ title: '专注锁定中', detail: '先完成当前目标，或在面板里停止并解锁。' });
        } else {
          showToast({ title: '已锁定', detail: '先解锁再操作。' });
        }
        return;
      }
      if (lpTriggered) return;
      setTaskDone(i, !state.done[i]);
    });

    gridEl.appendChild(btn);
  }

  syncSheet();
}

function resetDone() {
  state.done = state.done.map(() => false);
  state.priorityIndex = null;
  state.focus.locked = false;
  state.focus.index = null;
  state.focus.timer.running = false;
  state.focus.timer.startedAt = 0;
  state.focus.timer.lastAccAt = 0;
  state.focus.timer.notified = false;
  saveState();
  prevLineCount = 0;
  toast.hidden = true;
  render();
}

function randomizeTasks() {
  state.tasks = pickTasks().map((text) => ({ text, steps: [] }));
  state.done = state.done.map(() => false);
  state.day = todayKey();
  state.priorityIndex = null;
  state.lastIndex = null;
  state.focus.locked = false;
  state.focus.index = null;
  state.focus.timer.running = false;
  state.focus.timer.startedAt = 0;
  state.focus.timer.lastAccAt = 0;
  state.focus.timer.notified = false;
  saveState();
  prevLineCount = 0;
  toast.hidden = true;
  render();
}

toastClose.addEventListener('click', () => {
  toast.hidden = true;
});

resetBtn.addEventListener('click', resetDone);
randomizeBtn.addEventListener('click', randomizeTasks);

openSheetBtn.addEventListener('click', () => {
  const idx = currentIndexForSheet();
  if (idx === null) {
    showToast({ title: '先点一个格子', detail: '点击任意格子后，再打开“当前任务”。' });
    return;
  }
  openSheet();
});

overlay.addEventListener('click', closeSheet);
sheetClose.addEventListener('click', closeSheet);

toggleDoneBtn.addEventListener('click', () => {
  const idx = currentIndexForSheet();
  if (idx === null) return;
  if (isCellLocked(idx)) return;
  setTaskDone(idx, !state.done[idx]);
});

toggleCoreBtn.addEventListener('click', () => {
  const idx = currentIndexForSheet();
  if (idx === null) return;
  togglePriority(idx);
});

reasonPills.forEach((pill) => {
  pill.addEventListener('click', () => {
    const idx = currentIndexForSheet();
    if (idx === null) return;
    state.tasks[idx].selectedReason = pill.dataset.reason || '';
    saveState();
    syncSheet();
  });
});

timerModeChips.forEach((chip) => {
  chip.addEventListener('click', () => {
    if (state.focus.timer.running) {
      showToast({ title: '计时中', detail: '先停止并解锁，再切换模式。' });
      return;
    }
    state.focus.timer.mode = chip.dataset.mode === 'countup' ? 'countup' : 'countdown';
    saveState();
    syncSheet();
  });
});

presetBtns.forEach((btn) => {
  btn.addEventListener('click', () => {
    if (state.focus.timer.running) return;
    const sec = Number(btn.dataset.sec);
    state.focus.timer.presetSec = clampInt(sec, 60, 7200, 1500);
    saveState();
    syncSheet();
  });
});

startBtn.addEventListener('click', () => {
  const idx = currentIndexForSheet();
  if (idx === null) return;
  if (isCellLocked(idx)) return;
  if (isPriorityActive() && idx !== state.priorityIndex) {
    showToast({ title: '先完成能量核心', detail: '核心没完成前，不能开始其它任务。' });
    return;
  }
  startFocusTimer(idx);
  showToast({ title: '已锁定', detail: '一次只干一件事。' });
  syncSheet();
});

stopBtn.addEventListener('click', () => {
  stopFocusTimer({ unlock: true, silent: false, skipRecovery: false });
  syncSheet();
});

autoBreakBtn.addEventListener('click', () => {
  const idx = currentIndexForSheet();
  if (idx === null) return;
  if (isCellLocked(idx)) return;
  ensureSteps(idx);
  if (state.tasks[idx].steps.length === 0) {
    state.tasks[idx].steps = suggestSteps(state.tasks[idx].text);
  } else {
    const extra = suggestSteps(state.tasks[idx].text).slice(0, 2);
    state.tasks[idx].steps.push(...extra);
  }
  saveState();
  syncSheet();
  showToast({ title: '已拆解', detail: '现在只要点掉一个小块就能前进。' });
});

markInterruptedBtn.addEventListener('click', () => {
  const idx = currentIndexForSheet();
  if (idx === null) return;
  markInterrupted(idx, state.tasks[idx].selectedReason);
});

resumeTaskBtn.addEventListener('click', () => {
  const idx = currentIndexForSheet();
  if (idx === null) return;
  resumeInterruptedTask(idx);
});

window.addEventListener('resize', () => {
  resizeConfetti();
});

// Timer tick: micro pressure (countdown) and focus seconds accumulator.
window.setInterval(() => {
  if (!state.focus.timer.running) return;
  tickTimer(false);
  const d = derivedTimer();
  if (state.focus.timer.mode === 'countdown' && d.remaining === 0 && !state.focus.timer.notified) {
    state.focus.timer.notified = true;
    saveState();
    showToast({ title: '时间到', detail: '收个尾就可以切换下一件事。' });
    stopFocusTimer({ unlock: true, silent: true, skipRecovery: true });
    closeSheet();
    return;
  }
  syncSheet();
}, 500);

render();
